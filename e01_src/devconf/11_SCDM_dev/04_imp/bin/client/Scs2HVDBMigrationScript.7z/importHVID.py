#! /usr/bin/env jython
# ===================================================
#   Script to Restore/Compute/Check/Generated a CDV
# ===================================================
import sys
import os
import traceback
from CfgInterface import CfgInterface

retCode = 0

# ================================
#               Main
# ================================

# Check the arguments
# -----------------------
if len(sys.argv) < 2:
	print "Usage: " + sys.argv[0] + " <VDC Name>"
	retCode = 1
else:
	vdcName=sys.argv[1]

	print "-----------------------"
	print "- " + os.time.strftime("%X %x") + "- Connect to the server"
	CfgInt=CfgInterface()
	print "-----------------------"
	
	try:
		try:						
			currentPath=os.getcwd()
			print "- " + os.time.strftime("%X %x") + "- Create CSV (01_LOAD_AREA.csv):" 
			fout=open(currentPath+"\\01_LOAD_AREA.csv","w")
			fout.writelines("ID,ELEMENT_NAME\n")
			fout.writelines(":R:A:area,CmAreaContainer\n")
			list_location=[]
			list_location=CfgInt.Query(vdcName,"//OpmLocation",['OpmCategoryName'])
			for l in list_location:
				fout.writelines(":R:A:area:"+l[0]+",Area\n")
				
			fout.close()
			print "- " + os.time.strftime("%X %x") + "- Create CSV (02-LOAD_SCADASubsystem.csv):" 
			fout=open(currentPath+"\\02-LOAD_SCADASubsystem.csv","w")
			fout.writelines("ID,ELEMENT_NAME,scsenvname,subsystemID,__DELETE__\n")
			fout.writelines(":R:A:subsystem,CmSubSystemContainer\n")
			list_Subsystem=[]
			list_Subsystem=CfgInt.Query(vdcName,"//SCADASubsystem",['ID'])
			idx=1
			for l in list_Subsystem:
				ENVNAME=l[0].replace(':R:A:DB_','')
				fout.writelines(":R:A:subsystem:"+ENVNAME+"ENVCONN,SCADASubsystem,"+ENVNAME+"ENV,"+str(idx)+"\n")
				fout.writelines(l[0]+",,,,true\n")
				idx=idx+1
			print "- " + os.time.strftime("%X %x") + "- Create CSV (03-LOAD_link_area_Subsystem.csv):" 
			fout.close()
			fout=open(currentPath+"\\03-LOAD_link_area_Subsystem.csv","w")
			fout.writelines("ID,lk0,lk1,lk2,lk3,lk4,lk5,lk6,lk7,lk8,lk9,lk10,lk11,lk12,lk13,lk14,lk15,lk16,lk17,lk18,lk19,lk20,lk21,lk22,lk23,lk24,lk25,lk26,lk27,lk28,lk29,lk30,lk31,lk32,lk33,lk34,lk35,lk36,lk37,lk38,lk39,lk40,lk41,lk42,lk43,lk44,lk45,lk46,lk47,lk48,lk49\n")
			
			list_basicnode=[]
			list_basicnode=CfgInt.Query(vdcName,"id(':R:A')/BasicNode")
			for l in list_basicnode:
				fout.writelines(l[0]+":link_area,"+l[0].replace(":R:A:",":R:A:area:")+"\n")
			list_subsystems=[]
			list_subsystems=CfgInt.Query(vdcName,"//BasicNode/BasicNode_link_subsystems[@lk0!='']",["ID","lk0","lk1","lk2","lk3","lk4","lk5","lk6","lk7","lk8","lk9","lk10","lk11","lk12","lk13","lk14","lk15","lk16","lk17","lk18","lk19","lk20","lk21","lk22","lk23","lk24","lk25","lk26","lk27","lk28","lk29","lk30","lk31","lk32","lk33","lk34","lk35","lk36","lk37","lk38","lk39","lk40","lk41","lk42","lk43","lk44","lk45","lk46","lk47","lk48","lk49"])
			#:R:A:CTV:link_area,:R:A:area:CTV
			for l in list_subsystems:
				fout.writelines(l[0]+","+l[1].replace(":R:A:DB_",":R:A:subsystem:")+"ENVCONN\n")
			#fout.close()
			#:R:A:CTV:link_subsystems,:R:A:subsystem:OCCENVCONN
			####Equipment level subsystem
			list_subsystems=[]
			list_subsystems=CfgInt.Query(vdcName,"//BasicEquipment/BasicEquipment_link_subsystems[@lk0!=''] || //POLE/POLE_link_subsystems[@lk0!=''] || //CTRT/CTRT_link_subsystems[@lk0!='']",["ID","lk0","lk1","lk2","lk3","lk4","lk5","lk6","lk7","lk8","lk9","lk10","lk11","lk12","lk13","lk14","lk15","lk16","lk17","lk18","lk19","lk20","lk21","lk22","lk23","lk24","lk25","lk26","lk27","lk28","lk29","lk30","lk31","lk32","lk33","lk34","lk35","lk36","lk37","lk38","lk39","lk40","lk41","lk42","lk43","lk44","lk45","lk46","lk47","lk48","lk49"])
			#:R:A:CTV:link_area,:R:A:area:CTV
			for l in list_subsystems:
				temp_str=l[0]
				for i in range(1, 50):
					if l[i]!='':
						temp_str=temp_str+","+l[i].replace(":R:A:DB_",":R:A:subsystem:")+"ENVCONN"
				fout.writelines(temp_str+"\n")
			fout.close()
		
			print "- " + os.time.strftime("%X %x") + "- Create CSV (04-LOAD_hvid.csv):"
			fout=open(currentPath+"\\04-LOAD_hvid.csv","w")
			fout.writelines("ID,hvid\n")
			list_Subsystem=CfgInt.Query(vdcName,"//SCADASubsystem")
			for l in list_Subsystem:
				list_basicNode=[]
				list_basicNode=CfgInt.Query(vdcName,"id(':R:A')/BasicNode[BasicNode_link_subsystems/@lk0='"+l[0]+"']//BasicEquipment[@hvid='']",['ID','name'])
				for b in list_basicNode:
					#fout.writelines(b[0]+","+l[0].replace(":R:A:DB_","")+"~"+b[1].replace(':','')+"\n")
					fout.writelines(b[0]+","+l[0].replace(":R:A:DB_","")+"_"+b[1].replace(':','')+"\n")
				list_basicNodeSYS=CfgInt.Query(vdcName,"id(':R:A')/BasicNode/BasicNode[BasicNode_link_subsystems/@lk0='"+l[0]+"']/BasicEquipment[@hvid='']",['ID','name'])
				for b2 in list_basicNodeSYS:
					fout.writelines(b2[0]+","+l[0].replace(":R:A:DB_","")+"_"+b2[1].replace(':','')+"\n")
			fout.close()
			
			print "------Create CDV " + "W_"+vdcName + "------"
			print "Current path: " + currentPath
			CfgInt.createVED("W_"+vdcName,"import for HV", vdcName)
			print "------Import CSV :01_LOAD_AREA.csv------"
			CfgInt.ImportCSV("W_"+vdcName,currentPath+"\\01_LOAD_AREA.csv")
			#os.remove(currentPath+"\\01_LOAD_AREA.csv")
			print "------Import CSV :02-LOAD_SCADASubsystem.csv------"
			CfgInt.ImportCSV("W_"+vdcName,currentPath+"\\02-LOAD_SCADASubsystem.csv")
			#os.remove(currentPath+"\\02-LOAD_SCADASubsystem.csv")
			print "------Import CSV :03-LOAD_link_area_Subsystem.csv------"
			CfgInt.ImportCSV("W_"+vdcName,currentPath+"\\03-LOAD_link_area_Subsystem.csv")
			#os.remove(currentPath+"\\03-LOAD_link_area_Subsystem.csv")
			print "------Import CSV :04-LOAD_hvid.csv------"
			####CfgInt.ImportCSV("W_"+vdcName,currentPath+"\\04-LOAD_hvid.csv")
			#os.remove(currentPath+"\\04-LOAD_hvid.csv")
			CfgInt.validateVED("W_"+vdcName)
			CfgInt.integrateVED("W_"+vdcName)
			print "-------------------------------"
		except:
			print "- Exception raised" 
			traceback.print_exc()
			print "--------------------------------"
			retCode = 1
	
	finally:
		print "- " + os.time.strftime("%X %x") + "- Close Connection to the server"
		CfgInt.Disconnect()
		print "-------------------------------"

# Return the completion status
# --------------------------------
sys.exit(retCode)
# ===================================================	
	