export class ScsOlsDef {
    public static READ_OLSLIST = 'ReadOlsList?listServer=';
    public static LST_NAME_PARAM = '&listName=';
    public static FIELD_LIST_PARAM = '&fieldList='
    public static FILTER_PARAM = '&filter='
    public static CLIENT_PARAM = '&clientName=';
}
