#! /usr/bin/env jython
# ===================================================
#   Script to Restore/Compute/Check/Generated a CDV
# ===================================================
import sys
import os
import traceback
from CfgInterface import CfgInterface

retCode = 0

# ================================
#               Main
# ================================

# Check the arguments
# -----------------------
if len(sys.argv) < 2:
	print "Usage: " + sys.argv[0] + " <VDC Name>"
	retCode = 1
else:
	vdcName=sys.argv[1]

	print "-----------------------"
	print "- " + os.time.strftime("%X %x") + "- Connect to the server"
	CfgInt=CfgInterface()
	print "-----------------------"
	
	try:
		try:						
			print "- " + os.time.strftime("%X %x") + "- Restore the CDV :" 
			CfgInt.restoreCDV(vdcName)
			print "-------------------------------"
		except:
			print "- Exception raised" 
			traceback.print_exc()
			print "--------------------------------"
			retCode = 1
	
	finally:
		print "- " + os.time.strftime("%X %x") + "- Close Connection to the server"
		CfgInt.Disconnect()
		print "-------------------------------"

# Return the completion status
# --------------------------------
sys.exit(retCode)		

# ===================================================	
	